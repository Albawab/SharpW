# Meal Ordering

This project is being developed for the purpose of teaching Blazor tech on the Youtube Channel. With a tutorial video series on Youtube, 
I applied all the changes that I explained in the videos to this project and shared them with the audience. This project is developed based on WebAssemlby with Blazor.


This project represents a simple meal ordering system for office employees who have to order their food from restaurants around. In this project, people will be able to
create an order with a restaurant and their menu in the system and the other people can create order items that represent what they want to order.

In this project, as a database, Postgresql is used which is managed by EntityFramework ORM tool with CodeFirst approach. Clean Architecture and some best practices are 
tried to be used correctly in this project.
