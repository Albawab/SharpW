﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MealOrdering.Shared.DTO
{
    public class UserLoginRequestDTO
    {
        public String Email { get; set; }

        public String Password { get; set; }

    }
}
